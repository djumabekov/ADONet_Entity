DROP DATABASE IF EXISTS MusicStore;
CREATE DATABASE MusicStore; 
USE MusicStore;

DROP TABLE IF EXISTS Groups;
CREATE TABLE Groups
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 GroupName VARCHAR(255) NOT NULL,
);

DROP TABLE IF EXISTS Publishers;
CREATE TABLE Publishers
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 PublisherName VARCHAR(255) NOT NULL,
);

DROP TABLE IF EXISTS Genres;
CREATE TABLE Genres
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 GenrerName VARCHAR(255) NOT NULL,
);

DROP TABLE IF EXISTS Records;
CREATE TABLE Records
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 RecordName VARCHAR(255) NOT NULL,
 IdGroup INT NOT NULL FOREIGN KEY REFERENCES Groups(Id) ON DELETE CASCADE,
 IdPublisher INT NOT NULL FOREIGN KEY REFERENCES Publishers(Id) ON DELETE CASCADE,
 IdGenre INT NOT NULL FOREIGN KEY REFERENCES Genres(Id) ON DELETE CASCADE,
 CountTrack int NOT NULL,
 PublishYear Date NOT NULL,
 CostPrice Money NOT NULL,
 SellingPrice Money NOT NULL,
 Count  int NOT NULL,
);

DROP TABLE IF EXISTS Sellers;
CREATE TABLE Sellers
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 SellerName VARCHAR(255) NOT NULL,
);

DROP TABLE IF EXISTS Buyers;
CREATE TABLE Buyers
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 BuyerName VARCHAR(255) NOT NULL,
 AccumAmount Money NOT NULL,
 Discount AS AccumAmount * 0.05
);

DROP TABLE IF EXISTS Sales;
CREATE TABLE Sales
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 IdRecord INT NOT NULL FOREIGN KEY REFERENCES Records(Id) ON DELETE CASCADE,
 IdSeller INT NOT NULL FOREIGN KEY REFERENCES Sellers(Id) ON DELETE CASCADE,
 IdBuyer INT NOT NULL FOREIGN KEY REFERENCES Buyers(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
 TotalPrice Money NOT NULL,
 SellDate Date NOT NULL,
);

DROP TABLE IF EXISTS Reserves;
CREATE TABLE Reserves
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 IdRecord INT NOT NULL FOREIGN KEY REFERENCES Records(Id) ON DELETE CASCADE,
 IdBuyer INT NOT NULL FOREIGN KEY REFERENCES Buyers(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
);

DROP TABLE IF EXISTS Substracts;
CREATE TABLE Substracts
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 IdRecord INT NOT NULL FOREIGN KEY REFERENCES Records(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
);


DROP TABLE IF EXISTS Stocks;
CREATE TABLE Stocks
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 IdRecord INT NOT NULL FOREIGN KEY REFERENCES Records(Id) ON DELETE CASCADE,
 StockName VARCHAR(255) NOT NULL,
 StockPercent DECIMAL(3, 2) NOT NULL,
);

DROP TABLE IF EXISTS Users;
CREATE TABLE Users
(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 UserName VARCHAR(255) NOT NULL,
 Password VARCHAR(255) NOT NULL,
);


insert into Groups(GroupName) values ('Michael Jackson');
insert into Groups(GroupName) values ('AC/DC');
insert into Groups(GroupName) values ('Pink Floyd');
insert into Groups(GroupName) values ('Meat Loaf ');
insert into Groups(GroupName) values ('Eagles');
insert into Groups(GroupName) values ('Bee Gees/Various Artists');
insert into Groups(GroupName) values ('Fleetwood Mac');
insert into Groups(GroupName) values ('VA');
insert into Groups(GroupName) values ('Led Zeppelin');
insert into Groups(GroupName) values ('The Beatles.');

insert into Publishers(PublisherName) values ('Bad Boy Records');
insert into Publishers(PublisherName) values ('Edition Peters');
insert into Publishers(PublisherName) values ('Marvel Music');

insert into Genres(GenrerName) values ('���');
insert into Genres(GenrerName) values ('���');
insert into Genres(GenrerName) values ('���-���');
insert into Genres(GenrerName) values ('���');
insert into Genres(GenrerName) values ('R&B');
insert into Genres(GenrerName) values ('����');

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Thriller', 1, 1, 1, 8, '01-01-1982', 5500, 12, 7500);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Back in Black', 2, 6, 2, 7, '01-01-1980', 4300, 8, 6400);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('The Dark Side of the Moon', 3, 3, 3, 6, '01-01-1973', 7600, 16, 8600);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Bat Out of Hell', 4, 3, 1, 9, '01-01-1977', 3590, 16, 8600);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Their Greatest Hits 1971 � 1975', 5, 3, 2, 5, '01-01-1976', 6100, 14, 7800);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Saturday Night Fever', 6, 3, 3,533, '01-01-1977', 4700, 11, 6300);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Rumours', 7, 4, 1, 7, '01-01-1977', 8200, 18, 9800);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Grease: The Original Soundtrack for the Motion Picture', 8, 4, 2, 6, '01-01-1978', 7350, 15, 8650);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Led Zeppelin IV', 9, 4, 3, 5, '01-01-1971', 4700, 6, 6400);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Sgt. Pepper�s Lonely Hearts Club Band', 10, 5, 1, 12, '01-01-1967', 5300, 7, 7700);

insert into Records(RecordName, IdGroup, IdGenre, IdPublisher, CountTrack, PublishYear, CostPrice, Count, SellingPrice) 
values ('Universal', 3, 2, 1, 10, '01-01-2022', 7800, 13, 9300);

insert into Sellers(SellerName) values ('������ �.�.');
insert into Sellers(SellerName) values ('������ �.�.');
insert into Sellers(SellerName) values ('������� �.�.');

insert into Buyers(BuyerName, AccumAmount) values ('������ �.�.', 10000);
insert into Buyers(BuyerName, AccumAmount) values ('������� �.�.', 9000);
insert into Buyers(BuyerName, AccumAmount) values ('����� �.�.', 8000);

insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 1, 1, 1, 1000, '25-07-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 2, 2, 2, 1000, '25-07-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 3, 3, 3, 1000, '25-07-2022');

insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (3, 3, 3, 3, 3000, '23-07-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 1, 1, 4, 4000, '22-07-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 2, 2, 5, 5000, '21-07-2022');

insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 1, 1, 1, 2000, '26-06-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 2, 2, 2, 2000, '27-06-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 3, 3, 3, 2000, '28-06-2022');

insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 1, 1, 1, 2000, '21-06-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 2, 2, 2, 2000, '21-06-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 3, 3, 3, 2000, '21-06-2022');

insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (3, 3, 3, 3, 3000, '20-05-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 1, 1, 4, 4000, '19-04-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 2, 2, 5, 5000, '18-03-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (3, 3, 3, 6, 6000, '17-02-2022');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 1, 1, 7, 7000, '16-01-2021');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (2, 2, 2, 8, 8000, '15-12-2021');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (3, 3, 3, 9, 9000, '14-11-2021');
insert into Sales(IdRecord, IdSeller, IdBuyer, Count, TotalPrice, SellDate) values (1, 1, 1, 10, 10000, '13-10-2021');


insert into Stocks(IdRecord, StockName, StockPercent) values (1, '� 1 ��������', 0.12);
insert into Stocks(IdRecord, StockName, StockPercent) values (2, '� ��� �����������', 0.10);
insert into Stocks(IdRecord, StockName, StockPercent) values (3, '� ��� �������������', 0.16);
insert into Stocks(IdRecord, StockName, StockPercent) values (4, '� ������ ����', 0.5);
insert into Stocks(IdRecord, StockName, StockPercent) values (4, '� �������', 0.7);